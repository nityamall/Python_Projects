n=' '
s=ord(n)
print("%d"%s)
b=97
p=chr(b)
print(p)