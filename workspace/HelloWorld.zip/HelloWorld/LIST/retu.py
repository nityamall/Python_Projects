def may (myage):
    f_age=myage/2+7
    return f_age
n=may(97)
print("THE TEAM'S AGE IS",n)

