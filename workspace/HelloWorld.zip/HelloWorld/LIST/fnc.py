def calc (n):
    result=n*7
    print (result)
calc(5)
calc(9)
calc(4)
calc(12)