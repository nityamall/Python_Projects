n=[2,5,12,13,17]
for i in range (1,20):
    if i in n :
        continue
    print (i)