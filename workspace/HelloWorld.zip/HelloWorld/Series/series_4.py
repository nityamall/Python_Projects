n=input("ENTER THE THE LIMIT")
n=int(n)
f=0
s=0
for i in range (0,n):
    f=i*10+(i+1)
    s=s+f
print("%d"%s)