n=input("ENTER THE LIMIT")
n=int(n)
b=0
k=0
for i in range (1,n+1):
    b=(i*i)+1
    k=k+b
print("%d"%k)
