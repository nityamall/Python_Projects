n=input("ENTER A NO.")
n=int(n)
b=0
b=n%10
if (n%7==0 or b==7):
    print("BUZZ NO.")
else :
    print("NOT A BUZZ NO.")