plyr=input("Your fav male player -->").upper()
plyr1=input("Your fav female player -->").upper()
if plyr=="NADAL" and (plyr1=="SERENA" or plyr1=="SANIA"):
    print (" Good Job mate ..!!Right support..!!")
else:
    print (" Keepit up..Lets see who wins..!! -__-")