class girl:
    gender="Female"
    def __init__(self,name):
        self.name=name
r=girl("Rachel")
s=girl("Nitya")

print(r.gender)
print(r.name)

print(s.gender)
print(s.name)