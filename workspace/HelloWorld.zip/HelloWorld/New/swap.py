m=input ("m= ")
n=input ("n= ")
m=int(m)
n=int(n)
m=m+n
n=m-n
m=m-n
print("m=%d"%m)
print("n=%d"%n)