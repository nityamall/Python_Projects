class passing:
    def pillow(self):
        print("PASSING THE PILLOW !!!")
class punishment1:
    def situps(self):
        print("DO 990005 SITUPS")
class punishment2:
    def donkey(self):
        print("SAY THAT U ARE A DONKEY 1880863 TIMES")
class game(passing,punishment1,punishment2):
    pass
ob=game()
ob.pillow()
ob.situps()
ob.donkey()
