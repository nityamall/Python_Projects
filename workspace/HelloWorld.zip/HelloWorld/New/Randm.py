def food():
    print("I love chocolates.")
