x=4
x=int(x)
for i in range (0,x+1):
    for j in range (0,i):
        print("*", end=" ")
    print()

