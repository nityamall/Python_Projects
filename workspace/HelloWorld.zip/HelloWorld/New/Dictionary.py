english={'mad->':'someone who is unsound','sad->':'someone who is unhappy','red->':'a colour','whatsapp->':'an addicting app'}

print(english['whatsapp->'])

for k,v in english.items():
    print(k+v)