import Randm
import random
Randm.food()
x=random.randrange(1,1000)
print(x)