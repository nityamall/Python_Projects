for i in range (1,5+1):
    print(i)