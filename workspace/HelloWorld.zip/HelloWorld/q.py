n=input("ENTER A SENTTENCE").upper()
m=n.split()
m.sort()
print(m)