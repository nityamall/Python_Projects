color=input("Enter ur fav color -->").upper()
if color =="BLACK":
    print("Mine too..Dark inside..")
    color1=input("Be specific -->") 
    if color1 =="DARK BLACK":
        print("Congo!! Same here !!")
    else:
        print(" U r not of my type..!!")
    print("Bye. Got to go...See u later..TTYL !!")
else:
    print("Ok !! Call me!!")

    